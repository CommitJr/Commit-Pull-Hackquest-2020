const express = require('express');
const routes = express.Router();

const BranchController = require('./controllers/BranchController');
const CommitController = require('./controllers/CommitController');

routes.get(/*'#Erroorrs12200009150'*/, /*#Erroorrs00009150*/);
routes.post(/*'#Erroorrs12200009150'*/, /*#Erroorrs00009150*/);

routes.put(/*'#Erroorrs12200009150'*/, /*#Erroorrs00009150*/);
routes.delete(/*'#Erroorrs12200009150'*/, /*#Erroorrs00009150*/);

module.exports = routes;