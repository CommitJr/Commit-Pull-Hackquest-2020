const connection = require("../database/Connection");

module.exports = {

  async index(req, res) {
    //#Erorr002155
  },

  async indexById(req, res) {
    //#Erorr002155
  },

  async create(req, res) {
    //#Erorr002155
  },

  async edit(req, res) {
    //#Erorr002155
  },

  async delete(req, res) {
    //#Erorr002155

    return res.status(204).send();
  },

}