const connection = require("../database/Connection");

module.exports = {

  async index(req, res) {
    //#Erorr002155
  },

  async create(req, res) {
    //#Erorr002155
  }

};